define([
    'angular',
    'angularMocks',
    'module/js/controller'

], function (angular) {
    var Controller, $rootScope, $scope;
    describe('Unit Test: Controller Unit Test', function () {
        //Load the Module
        beforeEach(module('NewModuleName'));
        //Setup the test environment before each test
        beforeEach(inject(function($controller){
           $scope = {};
           Controller = $controller('NewModuleController', {$scope: $scope});
        }));
        it('Should have loaded the controller', function(){
            expect(Controller).toBeDefined();
            expect($scope).toBeDefined();
        });
    });
});