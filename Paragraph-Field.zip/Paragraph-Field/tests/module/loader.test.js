/**
 * Make sure we properly load all the files for proper karma coverage report
 */
define([
    'angular',
    'angularMocks',
    'module/js/loader'
], function (angular) {});