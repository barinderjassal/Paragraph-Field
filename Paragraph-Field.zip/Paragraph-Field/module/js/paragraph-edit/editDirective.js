define([
    'angular',
    'text!module/js/paragraph-edit/editTemplate.html',
    'module/js/paragraphformfield',
    'module/js/controller'
], function (angular, template) {
    angular.module('ParagraphFormField').directive('paragraphFormFieldEditDirective', [function () {
        return {
            restrict: 'EA',
            template: template,
            controller: 'ParagraphFormFieldController',
            scope: {
                fieldOptions: '='
            },
            link: function (scope, element, attrs) {
				
				
            }
        };
    }]);
})