define([
    'module/js/paragraph-edit/editDirective',
    'module/js/paragraph-settings/settingDirective',
    'module/js/paragraph-view/viewDirective'
], function(){});