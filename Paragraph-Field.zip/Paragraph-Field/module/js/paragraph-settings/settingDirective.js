/**
 * Created by Leon Cutler on 1/15/15.
 * Description:
 *
 */

define([
    'angular',
    'text!module/js/paragraph-settings/settingTemplate.html',
    'module/js/paragraphformfield',
    'module/js/controller'
], function(angular, template) {
    angular.module('ParagraphFormField').directive('paragraphFormFieldSettingsDirective', ['$sce', function ($sce) {
        return {
            restrict: 'AE',
            template: template,
            controller: 'ParagraphFormFieldController',
            scope: {
				fieldOptions: '='
            },
            link: function(scope, element, attrs) {
                
				/*scope.checkMandatory = function ()  {
					if (scope.fieldOptions.is_mandatory != undefined) {
						scope.fieldOptions.is_mandatory = !scope.fieldOptions.is_mandatory
					}	
				};*/
				
				scope.toggleLargerTextarea = function () {
                    scope.fieldOptions.is_large_text = !scope.fieldOptions.is_large_text;
                    if (scope.fieldOptions.is_large_text === true)
                        scope.fieldOptions.charLimit = 8000;
                    else
                        scope.fieldOptions.charLimit = 4000;
                };
                
                scope.$watch('fieldOptions.default_value', function (newV, oldV) {
                    if (scope.config) {
                        scope.config.modelVal = newV;
                        console.log(newV);
                    } 
                });
                              
            }
        };
    }]);
});