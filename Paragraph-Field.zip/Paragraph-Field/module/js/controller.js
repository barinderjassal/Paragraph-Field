define([
    'angular',
    'module/js/paragraphformfield'
], function (angular) {
    angular.module('ParagraphFormField').controller('ParagraphFormFieldController', ['$scope', '$sce', function ($scope, $sce) {
        
        $scope.displayTooltip = false;
        $scope.showTooltip = function() {
            $scope.displayTooltip = true;
        };
        $scope.hideTooltip = function() {
            $scope.displayTooltip = false;
        };
        
        $scope.rteConfig = {
            options: {
                onChange: function(e) {
                  // put logic here for keypress and cut/paste changes
                },
                height: 200,
                menubar: 'file edit insert view format table tools',
                plugins: 'spellchecker',
                skin: 'lightgray',
                theme : 'modern',
                browser_spellcheck: true
            },
            value: "<p>Hello World from RTE!</p>", //$scope.fieldOptions.default_value,
            RTEname: 'Demo RTE',
            charLimit: 4000
        };
        
        
        $scope.initialValueTextarea = $scope.fieldOptions.default_value; //initial value for paragraph field
        
        
        $scope.formatString = $sce.trustAsHtml($scope.fieldOptions.default_value);
        var getLength = $scope.formatString.toString().length;
        $scope.richCharsCovered = Math.round((getLength / $scope.fieldOptions.charLimit) * 100); // %age of RTE characters
        
        $scope.charsCovered = Math.round(($scope.fieldOptions.default_value.length / $scope.fieldOptions.charLimit) * 100);
        
        $scope.editValueRTE = function () {
            var formattedString = ($sce.trustAsHtml($scope.fieldOptions.default_value)).toString().length;
            $scope.richCharsCovered = Math.round((formattedString / $scope.fieldOptions.charLimit) * 100);
        };
                                             
        $scope.validateCharLimit = function () {
            $scope.charsCovered = Math.round(($scope.fieldOptions.default_value.length / $scope.fieldOptions.charLimit) * 100);     
        };
        
        $scope.save = function () {
            if ($scope.fieldOptions.allow_richtext) {
                $scope.formatString = $sce.trustAsHtml($scope.fieldOptions.default_value);
                var getLength = $scope.formatString.toString().length;  
            } else {
                $scope.initialValueTextarea = $scope.fieldOptions.default_value;
            }
            $scope.toggleDiv();
        };
              
        $scope.cancel = function () {
            if (!!$scope.fieldOptions.allow_richtext) {
                $scope.fieldOptions.default_value = $scope.formatString.toString();
            } else {
                var oldValue = angular.copy($scope.fieldOptions.default_value);                    
                $scope.fieldOptions.default_value = $scope.initialValueTextarea;
            }
            $scope.toggleDiv();
        };
                
        $scope.toggleDiv = function () {
            angular.element(document.querySelector('#modalBox')).toggleClass('hide');
        };
        
        $scope.$watch('fieldOptions.default_value', function (newVal, oldVal) {
            if (newVal.length > $scope.fieldOptions.charLimit) {
                $scope.fieldOptions.default_value = oldVal;
                alert('You have exceeded word limit');
            }
        });
        
    }]);
});
