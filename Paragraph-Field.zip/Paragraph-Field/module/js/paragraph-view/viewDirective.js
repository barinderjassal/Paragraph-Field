
define([
    'angular',
    'text!module/js/paragraph-view/viewTemplate.html',
    'module/js/paragraphformfield',
    'module/js/controller'
], function (angular, template) {
    angular.module('ParagraphFormField').directive('paragraphFormFieldViewDirective', [function () {
		
        return {
            restrict: 'EA',
            template: template,
            controller: 'ParagraphFormFieldController',
            scope: {
                fieldOptions: '='
            },
            link: function (scope, element, attrs) {
				if (scope.fieldOptions !== undefined && scope.fieldOptions !== '') {
					scope.optionValues = {
						display_name: scope.fieldOptions.display_name,
						allow_richtext: scope.fieldOptions.allow_richtext,
						is_read_only: scope.fieldOptions.is_read_only,
						is_disabled: scope.fieldOptions.is_disabled,
						default_value: scope.fieldOptions.default_value,
						charLimit: scope.fieldOptions.charLimit,
						is_mandatory: scope.fieldOptions.is_mandatory
					};
					
				} else {
					alert('Please provide field options object at user end');
				}
								
                scope.toggleLargerTextarea = function () {
                    scope.fieldOptions.is_large_text = !scope.fieldOptions.is_large_text;
                    if (scope.fieldOptions.is_large_text === true)
                        scope.fieldOptions.charLimit = 8000;
                    else
                        scope.fieldOptions.charLimit = 4000;
                };
            }
        };
    }]);
});