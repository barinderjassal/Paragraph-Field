define([
    'angular'
], function (angular) {
    angular.module('ParagraphFormField', ['ui.tinymce', 'CoreComponent']);
});