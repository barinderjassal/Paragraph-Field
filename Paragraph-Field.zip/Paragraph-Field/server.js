var NodeService = require('nodeserv').NodeServ,
    fs = require('fs');
/**
 * Load in the App Config
 */
var appconfig = JSON.parse(fs.readFileSync('appconfig.json', 'utf8'));
/**
 * Simple Routing for showing the main HBS template
 * This should be in a routes.js file under server/lib in a real app
 */
var routes = function(req, res){
    var pageData = {
        user: JSON.stringify({ 
            id: '123456789',
            first: 'Testy',
            last: 'McTest',
            ifg: 'GE Digital'
        }),
        paths: JSON.stringify(appconfig.apipaths),
        jspath: appconfig.structpaths.js,
        csspath: appconfig.structpaths.css,
        applications: JSON.stringify(appconfig.applications)
    };
    res.render('index', pageData);
};
/**
 * Node Serv
 * Instantiate a new Server Module
 */
var nodeServ = new NodeService(appconfig);
/**
 * NodeServ Configurations
 */
nodeServ.createServer();
nodeServ.configureTemplateEngine('hbs', 'handlebars');
nodeServ.hostStaticContent(__dirname);
nodeServ.hostStaticContent(__dirname + '/server');
nodeServ.hostStaticContent(__dirname + '/module');
nodeServ.setViewsDirectory(__dirname + '/server');
nodeServ.enableHttpProxy('/http_proxy/*');
nodeServ.registerProxy('gatekeeper', '/internal_proxy/*', appconfig.gatekeeper);
nodeServ.registerProxy('gatekeeper', '/proxy/*', appconfig.gatekeeper);
/**
 * Application Routes
 */
nodeServ.registerURL('get', '/', routes, false);
/**
 * Start Node Service
 */
nodeServ.startService(appconfig.listenIP, appconfig.listenPort);