/**
 * Created by leon on 5/19/14.
 */

/*
 * defineRequirements - These are the loaders for all of the modules, or packages needed
 * angularRequirements - This is the list of module names that will be feed into the app
 */

var defineRequirements = [
    'angular',
	'angularBootstrap',
    'tinymce_file',
    'angular_ui_tinymce',
    'moduleLoader',
    'server/js/sample/loader',
    'core_component',
    'core_richtext',
    'core_richtext_server'
], angularRequirements = [
    'ui.bootstrap',
    'ui.tinymce',
    'ParagraphFormField',
    'SampleParagraphFormField',   
    'CoreComponent'
];

define('app', defineRequirements, function (angular) {
    var app = angular.module('app', angularRequirements);
});