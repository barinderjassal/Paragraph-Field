define([
    'angular',
    'server/js/sample/sample'
], function (angular) {
    angular.module('SampleParagraphFormField').controller('SampleParagraphFormFieldController', ['$scope', function ($scope) {
            
        $scope.fieldOptions = {
            is_hidden : false,
            is_mandatory: false,
            is_read_only: false,
            is_searchable: false,
            is_edit_lock_for_admin: false,
            allow_richtext: false,
            is_large_text: false,
            default_value: "Hello World",
            display_name: 'Paragraph Field',
            charLimit: 4000,
            disabled: true,
            hide_setting_mode: false,
			is_disabled: false
        };
		
		console.log($scope.fieldOptions);
       
        $scope.action = 'Enable';
        $scope.selected = false;
        $scope.mode = {
            settings: true,
            edit: false,
            view: false
        };
        
        $scope.editable = function() {
            $scope.fieldOptions.disabled = !$scope.fieldOptions.disabled;
            $scope.action = $scope.fieldOptions.disabled === false ? 'Disable' : 'Enable';
        };
        
        $scope.selectField = function() {
            $scope.selected = true;
        };
        
        $scope.switchMode = function(selection) {
            for (var key in $scope.mode) {
                if (key === selection) {
                    $scope.mode[selection] = true;
                    $scope.selected = false;
                    if (key === 'settings') {
                        $scope.fieldOptions.disabled = true;
                    }
                } else {
                    $scope.mode[key] = false;
                }
            }
        };
        
    }]);
});
