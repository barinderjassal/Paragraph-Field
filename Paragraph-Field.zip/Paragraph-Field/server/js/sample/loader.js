define([
    'server/js/sample/directive',
], function(){});