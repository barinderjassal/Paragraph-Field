define([
    'angular'
], function (angular) {
    angular.module('SampleParagraphFormField', []);
});