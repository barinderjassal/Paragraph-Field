/**
 * Created by Leon Cutler on 1/15/15.
 * Description:
 *
 */
define([
    'angular',
    'text!server/js/sample/template.html',  
    'server/js/sample/sample',
    'server/js/sample/controller'
], function (angular, template) {
    angular.module('SampleParagraphFormField').directive('sampleParagraphFormField', [function () {
        return {
            restrict: 'EAC',
            template: template,
            replace: false,
            scope: false,
            controller: 'SampleParagraphFormFieldController'
        };
    }]);
});

