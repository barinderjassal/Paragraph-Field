require.config({
    baseUrl: '/',
    paths: {
        'angular': '/server/bower_components/angular/angular',
        'domready': '/server/bower_components/requirejs-domready/domReady',
        'text': '/server/bower_components/requirejs-text/text',
        'app': '/server/js/app',
        'angularBootstrap': '/server/bower_components/angular-bootstrap/ui-bootstrap-tpls',
        'moduleLoader': '../../module/js/loader',
        'tinymce_file': '/server/bower_components/tinymce/tinymce',
        'angular_ui_tinymce': '/server/bower_components/angular-ui-tinymce/src/tinymce',
        'core_component': '/server/bower_components/core_component/build/module.build',
        'core_richtext': '/server/bower_components/core_richtext/build/module.build',
        'core_richtext_server': '/server/bower_components/core_richtext/build/server.build'
    },
    shim: {
        angular: { exports: 'angular' },
        angularBootstrap: {
            deps: ['angular']
        },
        angular_ui_tinymce: {
            deps: ['angular', 'tinymce_file']
        },
        core_component: {
            deps: ['angular']
        },
        core_richtext: {
            deps: ['angular']
        },
        core_richtext_server: {
            deps: ['angular']            
        }
    }
});

require(['domready', 'angular', 'app'], function (domReady, angular) {
    domReady(function () {
        angular.bootstrap(document, ['app']);
    });
});
